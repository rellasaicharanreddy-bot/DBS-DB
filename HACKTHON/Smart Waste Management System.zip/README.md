# EcoTrack Smart Waste Management — Robust CSS Fix

## To see the designed website
1. Extract the ZIP to a normal Windows folder.
2. Double-click `VIEW_DESIGN.html` to confirm the visual design. Its CSS is embedded in the HTML, so the page will not become plain browser-default text if the stylesheet path fails.
3. For the complete working application, double-click `OPEN_ECOTRACK.bat` and open `http://127.0.0.1:5000`.

## Important distinction
- `VIEW_DESIGN.html` / root `index.html`: visual preview. Some database actions require Flask.
- `OPEN_ECOTRACK.bat`: full application with Python Flask, SQLite and API endpoints.
- `templates/index.html`: Flask template. It includes an inline CSS fallback and should normally be served by Flask.

## Separate source files are included
- `static/style.css`
- `static/app.js`
- `templates/index.html`
- `app.py`
- `requirements.txt`

Do not open a template directly from inside the ZIP archive. Extract the project first.
