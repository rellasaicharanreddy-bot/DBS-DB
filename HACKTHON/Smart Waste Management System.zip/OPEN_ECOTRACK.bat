@echo off
cd /d "%~dp0"
call RUN_WINDOWS.bat
