from flask import Flask, render_template, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, date, timedelta
from sqlalchemy import func
import random

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///smart_waste.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)

class Location(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    area = db.Column(db.String(120), nullable=False)
    latitude = db.Column(db.Float, default=17.385)
    longitude = db.Column(db.Float, default=78.4867)

class WasteCategory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(60), unique=True, nullable=False)
    color = db.Column(db.String(20), default="#16a085")

class Team(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    lead = db.Column(db.String(100), nullable=False)
    members = db.Column(db.Integer, default=3)
    phone = db.Column(db.String(30), default="")

class Bin(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(30), unique=True, nullable=False)
    location_id = db.Column(db.Integer, db.ForeignKey("location.id"), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey("waste_category.id"), nullable=False)
    capacity = db.Column(db.Integer, default=100)
    fill_level = db.Column(db.Integer, default=0)
    status = db.Column(db.String(30), default="Active")
    location = db.relationship("Location")
    category = db.relationship("WasteCategory")

class Schedule(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(120), nullable=False)
    bin_id = db.Column(db.Integer, db.ForeignKey("bin.id"), nullable=False)
    team_id = db.Column(db.Integer, db.ForeignKey("team.id"), nullable=False)
    scheduled_date = db.Column(db.Date, nullable=False)
    scheduled_time = db.Column(db.String(10), default="09:00")
    status = db.Column(db.String(30), default="Pending")
    bin = db.relationship("Bin")
    team = db.relationship("Team")

class Collection(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    bin_id = db.Column(db.Integer, db.ForeignKey("bin.id"), nullable=False)
    team_id = db.Column(db.Integer, db.ForeignKey("team.id"), nullable=False)
    collected_at = db.Column(db.DateTime, default=datetime.utcnow)
    quantity_kg = db.Column(db.Float, nullable=False)
    notes = db.Column(db.String(250), default="")
    bin = db.relationship("Bin")
    team = db.relationship("Team")

def seed():
    if Location.query.count():
        return
    locations = [
        Location(name="Central Park", area="Kukatpally"),
        Location(name="Market Street", area="Quthbullapur"),
        Location(name="Tech Campus", area="Miyapur"),
        Location(name="Lake View", area="Bachupally"),
    ]
    cats = [
        WasteCategory(name="General", color="#64748b"),
        WasteCategory(name="Recyclable", color="#0d9488"),
        WasteCategory(name="Organic", color="#65a30d"),
        WasteCategory(name="Hazardous", color="#e87936"),
    ]
    teams = [
        Team(name="Green Guardians", lead="Arjun Rao", members=5, phone="9876501201"),
        Team(name="Clean City Crew", lead="Meera Das", members=4, phone="9876501202"),
        Team(name="Eco Warriors", lead="Kiran Kumar", members=6, phone="9876501203"),
    ]
    db.session.add_all(locations + cats + teams)
    db.session.commit()
    for i in range(1, 13):
        db.session.add(Bin(
            code=f"BIN-{i:03d}", location_id=((i-1)%4)+1,
            category_id=((i-1)%4)+1, capacity=100,
            fill_level=random.randint(15, 98),
            status="Active" if i != 11 else "Maintenance"
        ))
    db.session.commit()
    for i in range(1, 7):
        db.session.add(Schedule(
            title=["Morning collection", "Afternoon pickup", "Evening route"][i%3],
            bin_id=i, team_id=((i-1)%3)+1,
            scheduled_date=date.today()+timedelta(days=(i%4)-1),
            scheduled_time=["08:00","10:30","14:00","16:30"][i%4],
            status="Completed" if i == 1 else "Pending"
        ))
    db.session.commit()
    for i in range(1, 9):
        db.session.add(Collection(
            bin_id=i, team_id=((i-1)%3)+1,
            collected_at=datetime.utcnow()-timedelta(days=i),
            quantity_kg=round(random.uniform(12, 48), 1),
            notes="Routine collection"
        ))
    db.session.commit()

@app.route("/")
def index():
    return render_template("index.html")

@app.get("/api/dashboard")
def dashboard():
    bins = Bin.query.all()
    collections = Collection.query.all()
    total_kg = sum(c.quantity_kg for c in collections)
    avg_fill = round(sum(b.fill_level for b in bins)/len(bins)) if bins else 0
    return jsonify({
        "total_bins": len(bins),
        "active_bins": sum(1 for b in bins if b.status == "Active"),
        "critical_bins": sum(1 for b in bins if b.fill_level >= 80),
        "collections": len(collections),
        "total_kg": round(total_kg, 1),
        "avg_fill": avg_fill,
        "recent": [collection_dict(c) for c in Collection.query.order_by(Collection.collected_at.desc()).limit(5)],
        "fill": [{"label": b.code, "value": b.fill_level} for b in bins[:8]]
    })

def collection_dict(c):
    return {"id": c.id, "bin": c.bin.code, "team": c.team.name,
            "date": c.collected_at.strftime("%d %b %Y, %I:%M %p"),
            "quantity": c.quantity_kg, "notes": c.notes}

@app.get("/api/bins")
def bins():
    return jsonify([{"id":b.id,"code":b.code,"location":b.location.name,"area":b.location.area,
        "category":b.category.name,"capacity":b.capacity,"fill":b.fill_level,"status":b.status}
        for b in Bin.query.order_by(Bin.id.desc()).all()])

@app.post("/api/bins")
def add_bin():
    d=request.get_json()
    try:
        b=Bin(code=d["code"],location_id=int(d["location_id"]),category_id=int(d["category_id"]),
              capacity=int(d.get("capacity",100)),fill_level=int(d.get("fill_level",0)),status="Active")
        db.session.add(b); db.session.commit()
        return jsonify({"ok":True}),201
    except Exception as e:
        db.session.rollback(); return jsonify({"error":str(e)}),400

@app.delete("/api/bins/<int:item_id>")
def delete_bin(item_id):
    b=Bin.query.get_or_404(item_id)
    if Schedule.query.filter_by(bin_id=b.id).first() or Collection.query.filter_by(bin_id=b.id).first():
        return jsonify({"error":"This bin has schedules or collection history and cannot be deleted."}),409
    db.session.delete(b); db.session.commit()
    return jsonify({"ok":True})

@app.get("/api/locations")
def locations():
    return jsonify([{"id":x.id,"name":x.name,"area":x.area} for x in Location.query.all()])

@app.get("/api/categories")
def categories():
    return jsonify([{"id":x.id,"name":x.name} for x in WasteCategory.query.all()])

@app.get("/api/teams")
def teams():
    return jsonify([{"id":x.id,"name":x.name,"lead":x.lead,"members":x.members,"phone":x.phone} for x in Team.query.all()])

@app.post("/api/teams")
def add_team():
    d=request.get_json()
    t=Team(name=d["name"],lead=d["lead"],members=int(d.get("members",3)),phone=d.get("phone",""))
    db.session.add(t); db.session.commit()
    return jsonify({"ok":True}),201

@app.get("/api/schedules")
def schedules():
    return jsonify([{"id":s.id,"title":s.title,"bin":s.bin.code,"team":s.team.name,
        "date":s.scheduled_date.isoformat(),"time":s.scheduled_time,"status":s.status}
        for s in Schedule.query.order_by(Schedule.scheduled_date.asc()).all()])

@app.post("/api/schedules")
def add_schedule():
    d=request.get_json()
    s=Schedule(title=d["title"],bin_id=int(d["bin_id"]),team_id=int(d["team_id"]),
        scheduled_date=date.fromisoformat(d["date"]),scheduled_time=d.get("time","09:00"))
    db.session.add(s); db.session.commit()
    return jsonify({"ok":True}),201

@app.patch("/api/schedules/<int:item_id>")
def update_schedule(item_id):
    s=Schedule.query.get_or_404(item_id)
    s.status=request.get_json().get("status","Pending")
    db.session.commit()
    return jsonify({"ok":True})

@app.get("/api/collections")
def collections():
    return jsonify([collection_dict(c) for c in Collection.query.order_by(Collection.collected_at.desc()).all()])

@app.post("/api/collections")
def add_collection():
    d=request.get_json()
    b=Bin.query.get_or_404(int(d["bin_id"]))
    c=Collection(bin_id=b.id,team_id=int(d["team_id"]),quantity_kg=float(d["quantity"]),
                 notes=d.get("notes",""))
    b.fill_level=0
    db.session.add(c); db.session.commit()
    return jsonify({"ok":True}),201

@app.get("/api/prediction")
def prediction():
    # Lightweight baseline forecast: recent average daily collection + current bin fill.
    rows=Collection.query.all()
    avg=(sum(x.quantity_kg for x in rows)/len(rows)) if rows else 25
    bins=Bin.query.all()
    expected=round(avg*1.12,1)
    high=[{"bin":b.code,"location":b.location.name,"fill":b.fill_level,
           "priority":"High" if b.fill_level>=80 else "Medium" if b.fill_level>=60 else "Low"}
          for b in sorted(bins,key=lambda x:x.fill_level,reverse=True)]
    return jsonify({"expected_kg":expected,"average_kg":round(avg,1),
        "message":"Estimated from historical collection averages. Add more collection records to improve the baseline.",
        "priority_bins":high[:6]})

@app.get("/api/health")
def health():
    return jsonify({"status":"ok"})

with app.app_context():
    db.create_all()
    seed()

if __name__ == "__main__":
    app.run(debug=False, host="127.0.0.1", port=5000)
