@echo off
setlocal
title EcoTrack - Smart Waste Management
cd /d "%~dp0"
echo.
echo ==========================================
echo       ECOTRACK SMART WASTE MANAGEMENT
echo ==========================================
echo Project folder: %CD%
echo.

where py >nul 2>nul
if not errorlevel 1 (
    set PYTHON=py -3
) else (
    where python >nul 2>nul
    if errorlevel 1 (
        echo ERROR: Python 3 was not found.
        echo Install Python 3.10 or newer from https://www.python.org/downloads/
        echo During installation, enable "Add Python to PATH".
        pause
        exit /b 1
    )
    set PYTHON=python
)

if not exist .venv (
    echo [1/3] Creating virtual environment...
    %PYTHON% -m venv .venv
    if errorlevel 1 goto error
)

call .venv\Scripts\activate.bat
if errorlevel 1 goto error

echo [2/3] Installing project dependencies...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 goto error

echo.
echo [3/3] Starting Flask server...
echo.
echo KEEP THIS WINDOW OPEN WHILE USING THE WEBSITE.
echo Open this exact address in Chrome:
echo http://127.0.0.1:5000
echo.
start "" http://127.0.0.1:5000
python app.py
goto end

:error
echo.
echo Startup failed. Read the error above.
pause

:end
pause
